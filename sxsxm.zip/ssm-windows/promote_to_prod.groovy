@Library('utils@master') _
import com.lmig.intl.cloud.jenkins.util.EnvConfigUtil
import com.lmig.intl.cloud.jenkins.constants.EnvConstants
def server = Artifactory.server "artifactory-server"
def envUtil = new EnvConfigUtil()
def ARTIFACT_VERSION = "$env.BUILD_NUMBER"

//Upload to artifactory and promote to prod steps
stage('Promote to prod')
{
    
    echo ("Deploying in Non Prod")
    node('linux'){
        checkout scm
        sh 'ls -al'    
        def artifacts = ['prod_Jenkinsfile','Templates/intl-WEM-ssmmaintenancewindow.json']
        artifactoryUploadFiles files:artifacts,version:ARTIFACT_VERSION
        promoteToProd(approver:'William.Parlour', email:'William.Parlour@libertyinsurance.ie', version:ARTIFACT_VERSION)	{}    
        }
}    
